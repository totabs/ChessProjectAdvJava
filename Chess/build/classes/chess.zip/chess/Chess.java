//SOROUSH AGHAJANI open the template in the editor.

package chess;

import static chess.Move.isEmpty;
import static chess.Move.truer;

/**
 *
 * @author aghaj
 */
public class Chess {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        truer();

        // TODO code application logic here
Pawn pawn1 = new Pawn();
Pawn pawn2 = new Pawn();
Pawn pawn3 = new Pawn();
Pawn pawn4 = new Pawn();
Pawn pawn5 = new Pawn();
Pawn pawn6 = new Pawn();
Pawn pawn7 = new Pawn();
Pawn pawn8 = new Pawn();
bigRook bigrook = new bigRook();
horse bigHorse = new horse();
Bishop bigBishop = new Bishop();
Queen queen = new Queen();
King king = new King();
Bishop smallBishop= new Bishop();
horse smallHorse = new horse();
Rook smallRook = new Rook(); 

pawn1.marker(0,1,pawn1);
pawn2.marker(1, 1, pawn2);
pawn3.marker(2, 1, pawn3);
pawn4.marker(3, 1, pawn4);
pawn5.marker(4, 1, pawn5);
pawn6.marker(5, 1, pawn6);
pawn7.marker(6, 1, pawn7);
pawn8.marker(7, 1, pawn8);
bigrook.marker(0,0,bigrook);
bigHorse.marker(1,0,bigHorse);
bigBishop.marker(2,0,bigBishop);
queen.marker(3, 0, queen);
king.marker(4, 0, king);
smallBishop.marker(5,0,smallBishop);
smallHorse.marker(6, 0, smallHorse);
smallRook.marker(7,0,smallRook);
//smallBishop.move(4,1,true,smallBishop);
//pawn3.move(2, 3, true, pawn3);
//System.out.println(isEmpty(6,0));
queen.move(3, 3, true, queen);
//pawn6.move(5, 2, true,pawn6);
//System.out.println(isEmpty(6,0));

//bigBishop.move(3,1,true,bigBishop);



//pawn5.move(3,0,true);
//pawn5.move(4, 3, true);
//pawn5.move(4, 4, true);
//pawn5.move(4, 5, true);
//pawn5.move(4, 6, true);
//pawn4.move(3, 3, true);
//smallHorse.move(7,2,true);
//queen.move(3, 1, true);
//smallHorse.newPos(0, 0, king);





    }
    
}
