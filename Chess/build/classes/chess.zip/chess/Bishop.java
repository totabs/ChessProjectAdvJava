//SOROUSH AGHAJANI
package chess;

/**
 *
 * @author aghaj
 */
public class Bishop extends Move{
    private  int i;
    private  int j;
    protected boolean isMovable(int i, int j,Move Bishop){
        boolean isempty = true;
        if(this.i < i && this.j < j){
            for(int d = this.i +1; d <= i ;d++){
                if(!isEmpty(d,d)){
                    isempty = false;
                break;
                }
            }
        }
        else if (this.i > i && this.j <j){
            int p = this.j +1;
            for(int d = this.i -1 ; d>= i; d--){
                if(!isEmpty(d,p)){
                    isempty = false;
                    break;
                }
            p++;
        }
        }
        else if(this.i > i && this.j> j){
            for(int d = this.i -1;d>=i;d--){
                if(!isEmpty(d,d)){
                    isempty = false;
                    break;
                }
            }
        }
        else if(this.i<i && this.j>j){
            int q = this.j -1;
            for(int d = this.i +1; d <= i;d++){
                if(!isEmpty(d,q)){
                    isempty = false;
                    break;
                }
            q--;
            }
        }
        return isempty;
    }
    public void move(int i , int j, boolean turn,Move Bishop){
    if( Math.abs(i - getXPos()) == Math.abs(j - getYPos())&&isMovable(i,j,Bishop)&& notPinned()&& !isOpp(i,j)){
       System.out.println("inside Bishop");
        marker(i,j,Bishop);
        System.out.println("its done");
       
    }
    else if (globTurn && Math.abs(i - getXPos()) == Math.abs(j - getYPos())&& isOpp(i,j)&& isMovable(i,j,Bishop)&& notPinned()){
                System.out.println("inside Bishop2");
        hit(i,j);

    }
    else
        wrongMove();
}

   protected void newPos(int i, int j, Move move) {
        this.i = i ;
        this.j = j ;
        if(globTurn == true){
            marker(i,j,move);
            globTurn=false;
        }
        else if(globTurn == false){
            marker(i,j,false);
            globTurn = true;
        }
            
    }

    @Override
    protected int getXPos() {
        return this.i;
    }

    @Override
    protected int getYPos() {
return this.j;
    }

    protected void marker(int i, int j, Object Bishop) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void setXPos(int i) {
         this.i =i;
    }

    @Override
    protected void setYPos(int j) {
        this.j = j;
    }
    
}
