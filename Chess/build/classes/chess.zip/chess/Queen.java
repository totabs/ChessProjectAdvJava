//SOROUSH AGHAJANI
package chess;

/**
 *
 * @author aghaj
 */
public class Queen extends Move {
        private int i;
    private int j;
    protected void move(int i, int j, boolean turn , Move queen){
         if(turn && Math.abs(i - getXPos()) == Math.abs(j - getYPos())&& isMovable(i,j,queen)&& notPinned()&& !isOpp(i,j)){
        marker(i,j,queen);
         System.out.println("doros gofti agha soroush");
         }
    else if (turn && Math.abs(i - getXPos()) == Math.abs(j - getYPos())&& isOpp(i,j)&& isMovable(i,j,queen)&& notPinned()){
        hit(i,j);
        System.out.println("bodo sorakh");
    }
    else if(turn &&getXPos()==i && getYPos() < j && j < 8 && j >= 0 && isMovable(i,j,queen)&& notPinned()&& !isOpp(i,j)){
            marker(i,j,queen);
       System.out.println("doros gofti agha soroush baz");
    }
        else if(turn &&getYPos() == j &&  (getXPos() < i || getXPos() > i) && i < 8 && i >= 0 && isMovable(i,j,queen)&& notPinned() &&  !isOpp(i,j) ){
        marker(i,j,queen);
        System.out.println("sorakhesh injast");
        }
                else if(turn &&getYPos() == j &&  getXPos() < i || getXPos() > i && i < 8 && i >= 0 && isMovable(i,j,queen)&& notPinned() &&  isOpp(i,j) ){
        hit(i,j);
        System.out.println("solakh");
                }
                else if(turn && getXPos()==i && getYPos() < j || getYPos() > j && j < 8 && j >= 0 && isMovable(i,j,queen)&& notPinned()&& isOpp(i,j)){
            hit(i,j);
            System.out.println("sorakhe kar");
                }
                else 
                    wrongMove();
        
    }
    protected boolean isMovable(int i, int j,Move queen){
   boolean  isempty = true;
        if(this.i < i && this.j < j){
            int p = this.j+1;
            for(int d = this.i+1; d <= i ;d++){
                if(!isEmpty(d,p)){
                    isempty = false;
                    System.out.println(isEmpty(d,p));
                break;
                }
            }
        }
        else if (this.i > i && this.j <j){
            int p = this.j + 1;
            for(int d = this.i-1 ; d>= i; d--){
                if(!isEmpty(d,p)){
                    isempty = false;
                    System.out.println(isEmpty(d,p));
                    break;
                }
            p++;
        }
        }
        else if(this.i > i && this.j> j){
            for(int d = this.i-1;d>=i;d--){
                if(!isEmpty(d,d)){
                    isempty = false;
                    System.out.println(isEmpty(d,d));
                    break;
                }
            }
        }
        else if(this.i<i && this.j>j){
            int q = this.j -1;
            for(int d = this.i+1; d <= i;d++){
                if(!isEmpty(d,q)){
                    isempty = false;
                    System.out.println(isEmpty(d,q));
                    break;
                }
            q--;
            }
        }
else if(this.i < i && this.j == j){
        for(int d = i ; d > this.i; d-- ){
            System.out.println("injaei?");
            if(!isEmpty(d,j)){
                isempty = false;
                System.out.println(isEmpty(d,j));
                break;
            }                
        }
         }
       else if(getXPos() > i && getYPos() == j){
        for(int d = getXPos()-1 ; d >= i; d-- ){
            if(!isEmpty(d,j)){
                isempty = false;
                System.out.println(isEmpty(d,j));
                break;
            }                
        }
         }
                else if(this.j < j && this.i == i){
                    int q =i;
        for(int d = this.j +1 ; d < j; d++ ){
            if(!isEmpty(q,d)){
                            System.out.println(isEmpty(q,d));

                isempty = false;
                break;
            }          
            
        }
         }
                else if(getYPos() > j && getXPos() == i){
        for(int d = getXPos() -1 ; d >= j; d-- ){
            if(!isEmpty(i,d)){
                isempty = false;
                System.out.println(isEmpty(i,d));
                break;
            }                
        }
         }
         return isempty;
    
    }
    
 protected void newPos(int i, int j, Move move) {
        this.i = i ;
        this.j = j ;
        if(globTurn == true){
            marker(i,j,move);
            globTurn=false;
        }
        else if(globTurn == false){
            marker(i,j,false);
            globTurn = true;
        }
            
    }
   

    @Override
    protected int getXPos() {
return this.i;
    }

    @Override
    protected int getYPos() {

return this.j;
    }

    protected void marker(int i, int j, Object Queen) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void setXPos(int i) {
         this.i =i;
    }

    @Override
    protected void setYPos(int j) {
        this.j = j;
    }

    
}
