// SOROUSH AGHAJANI
package chess;

/**
 *
 * @author aghaj
 */
public class King extends Move{
        private  int i;
    private  int j;
   private static boolean ischeck;
    private boolean neverMoved;
     protected void move(int i, int j, boolean turn, Move king){
         if(turn && Math.abs(getXPos()-i) == 1 || getXPos() == i && Math.abs(getYPos() - j )== 1 || getYPos()== j&& isMovable(i,j,king) && !isOpp(i,j)){
             newPos(i,j,king);
             neverMoved = false;
         }
         else if(turn && Math.abs(getXPos()-i) == 1 || getXPos() == i && Math.abs(getYPos() - j )== 1 || getYPos()== j &&isMovable(i,j,king)&& !isOpp(i,j)){
             hit(i,j);
             neverMoved = false;
         }
         else if(neverMoved && smallCastlable &&!isCheck()&& i == 6){
            smallCastle(new King(),new Rook(),i,j);
             neverMoved = false;
         }
         else if(neverMoved && bigCastlable &&!isCheck()&& i == 1){
             bigCastle(new King(), new bigRook(),i,j);
             neverMoved = false;
             
         }
         else 
             wrongMove();
     }
     
     private boolean isCheck(){
         return ischeck;
     }
         public void newPos(int i, int j,MoveInstable king) {
                     this.i = i ;
        this.j = j ;
                if(globTurn == true){
            king.marker(i,j,king);
            globTurn=false;
        }
        else if(globTurn == false){
            king.marker(i,j,king);
            globTurn = true;
        }
          
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
/*
     private boolean isSmallCastlable(){
         boolean bool = false;
         if(neverMoved && smallRCastlable(smallCastlable)){
            bool = true;
         }
         return bool;
     }
     */

    protected boolean isMovable(int i,int j,Move king){
        //check to see if the new place is under the range of opponent
        //check to make sure there is not the same type of pice on that spot
        isEmpty(i,j);
return true;
}

    @Override
    protected int getXPos() {
return this.i;
    }

    @Override
    protected int getYPos() {
return this.j;    }

 protected void newPos(int i, int j, Move move) {
        this.i = i ;
        this.j = j ;
        if(globTurn == true){
            marker(i,j,move);
            globTurn=false;
        }
        else if(globTurn == false){
            marker(i,j,move);
            globTurn = true;
        }
            
    }

    @Override
    protected void setXPos(int i) {
         this.i =i;
    }

    @Override
    protected void setYPos(int j) {
        this.j = j;
    }


}
