//SOROUSH AGHAJANI
package chess;

/**
 *
 * @author aghaj
 */
public class horse extends Move{
    private  int i;
    private  int j;
    
    protected boolean isMovable(int i, int j,Move horse){
        isEmpty(i,j);
        return true;
    }
    public void move(int i,int j,boolean color,Move horse){
        System.out.println("inside horse move");
        if((getXPos()+ 2) == i && (getYPos()+1) == j&& notPinned()&&isEmpty(i,j))
            newPos(i,j,horse);
        else if((getXPos()+ 2) == i && (getYPos()-1) == j&& notPinned()&& isEmpty(i,j))
            newPos(i,j,horse);
        else if((getXPos()+ 1) == i && (getYPos()+2) == j&& notPinned()&& isEmpty(i,j))
            newPos(i,j,horse);
        else if((getXPos()+ 1) == i && (getYPos()-2) == j&& notPinned()&& isEmpty(i,j))
            newPos(i,j,horse);
        else if((getXPos()- 2) == i && (getYPos()-1) == j&& notPinned()&& isEmpty(i,j))
            newPos(i,j,horse);
        else if((getXPos()- 2) == i && (getYPos()+1) == j&& notPinned()&& isEmpty(i,j))
            newPos(i,j,horse);
        else if((getXPos()- 1) == i && (getYPos()-2) == j&& notPinned()&& isEmpty(i,j))
            newPos(i,j,horse);
        else if((getXPos()- 1) == i && (getYPos()+2) == j&& notPinned()){
            newPos(i,j,horse);
            System.out.println("in here");
        }
               else if((getXPos()+ 2) == i && (getYPos()+1) == j&& notPinned()&&isOpp(i,j))
            hit(i,j);
        else if((getXPos()+ 2) == i && (getYPos()-1) == j&& notPinned()&& isOpp(i,j))
            hit(i,j);
        else if((getXPos()+ 1) == i && (getYPos()+2) == j&& notPinned()&& isOpp(i,j))
             hit(i,j);
        else if((getXPos()+ 1) == i && (getYPos()-2) == j&& notPinned()&& isOpp(i,j))
            hit(i,j);
        else if((getXPos()- 2) == i && (getYPos()-1) == j&& notPinned()&& isOpp(i,j))
             hit(i,j);
        else if((getXPos()- 2) == i && (getYPos()+1) == j&& notPinned()&& isOpp(i,j))
             hit(i,j);
        else if((getXPos()- 1) == i && (getYPos()-2) == j&& notPinned()&& isOpp(i,j))
             hit(i,j);
        else if((getXPos()- 1) == i && (getYPos()+2) == j&& notPinned()&& isOpp(i,j))
             hit(i,j);
        else
            wrongMove();
    }
        /*public void newPos(int i, int j) {
            this.i = i;
            this.j = j;
                    if(globTurn == true){
            marker(i,j,horse);
            globTurn=false;
        }
        else if(globTurn == false){
            marker(i,j,horse);
            globTurn = true;
        }
          
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }*/

    @Override
    protected int getXPos() {
        return this.i;
    }

    @Override
    protected int getYPos() {
       return this.j;
    }

    @Override
    protected void setXPos(int i) {
         this.i =i;
    }

    @Override
    protected void setYPos(int j) {
        this.j = j;
    }




}
