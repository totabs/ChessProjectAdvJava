//SOROUSH AGHAJANI
package chess;

/**
 *
 * @author aghaj
 */
public class Pawn extends Move {
    //MoveInstable moves = new MoveInstable();
    private  int i ;
    private  int j ;
    boolean movable;
    boolean isKing;
    boolean isUnpasan;
    
    private void Promotion(){
        
    }
    protected boolean isMovable(int i, int j,Move pawn){
       
        boolean isempty = true;
        for(int d = j; d > pawn.getYPos();d--){
            if(!isEmpty(i,d)){
                isempty = false;
                break;
               
            }
        }
        return isempty;
    }

    private boolean isKing(int i, int j ){
        return isKing;
    }
    private boolean isUnpasan(){
        return isUnpasan;
    }
    private void unpasan(){
        
    }
     @Override
    public void move(int i, int j, boolean color, Move pawn){
         System.out.println("inside pawn move" + pawn.getYPos());
        
        if(i==  pawn.getXPos() && j == 3 || j ==2&& notPinned()&& isMovable(i,j,pawn)&& !isOpp(i,j)){
        marker(i,j,pawn);
    }
        else if(i== getXPos()&& j == getYPos()+1 && j <8 && j >=0&& notPinned() && isMovable(i,j,pawn)&& !isOpp(i,j) ){
        marker(i,j,pawn);
        if( j == 7){
            Promotion();
        }
    }
        else if((getXPos() +1) == i || i == (getXPos() - 1) && j ==(getYPos()+1) && isOpp(i,j) && notPinned() ){
            hit(i,j);
        }
        else if(isUnpasan()){
            unpasan();
        }
        else 
            wrongMove();
    }


    public void newPos(int i, int j, Move pawn ) {
        
                this.i = i ;
        this.j = j ;
                if(globTurn == true){
            pawn.marker(i,j,pawn);
            globTurn=false;
        }
        else if(globTurn == false){
            pawn.marker(i,j,pawn);
            globTurn = true;
        }
         
    }

    @Override
    protected int getXPos() {
        
        return i;
    }

    @Override
    protected int getYPos() {
        return j;
    }

    @Override
    protected void setXPos(int i) {
        
       this.i =i;
    }

    @Override
    protected void setYPos(int j) {
        this.j = j;
    }








}
