//SOROUSH AGHAJANI
package chess;

/**
 *
 * @author aghaj
 */
public class Rook extends Move {
    private  int i;
    private  int j;
    protected void move(int i, int j, boolean turn, Move Rook){
        if(getXPos()==i && getYPos() < j || getYPos() > j && j < 8 && j >= 0 &&isMovable(i,j,Rook)&& notPinned()&& !isOpp(i,j)){
            newPos(i,j,Rook);
            smallCastlable = false;
        }
        else if(getYPos() == j &&  getXPos() < i || getXPos() > i && i < 8 && i >= 0 &&isMovable(i,j,Rook)&& notPinned() &&  !isOpp(i,j) ){
        newPos(i,j,Rook);
        smallCastlable = false;
        }
                else if(getYPos() == j &&  getXPos() < i || getXPos() > i && i < 8 && i >= 0 &&isMovable(i,j,Rook)&& notPinned() &&  isOpp(i,j) ){
        hit(i,j);
        smallCastlable = false;
                }
              else if(getXPos()==i && getYPos() < j || getYPos() > j && j < 8 && j >= 0 &&isMovable(i,j,Rook)&& notPinned()&& isOpp(i,j)){
            hit(i,j);
            smallCastlable = false;
              }
    }
    
    
    public void newPos(int i, int j,Move move) {
                this.i = i ;
        this.j = j ;
                if(globTurn == true){
            marker(i,j,move);
            globTurn=false;
        }
        else if(globTurn == false){
            marker(i,j,move);
            globTurn = true;
        }
          
    }

    @Override
    protected int getXPos() {
return this.i;
    }

    @Override
    protected int getYPos() {

return this.j;
    }


     protected boolean isMovable(int i,int j,Move Rook){
         boolean isempty = true;
         if(getXPos() < i && getYPos() == j){
        for(int d = getXPos()+1 ; d < i; d++ ){
            if(!isEmpty(d,j)){
                isempty = false;
                break;
            }                
        }
         }
       else if(getXPos() > i && getYPos() == j){
        for(int d = getXPos()-1 ; d >= i; d-- ){
            if(!isEmpty(d,j)){
                isempty = false;
                break;
            }                
        }
         }
                else if(getYPos() < j && getXPos() == i){
        for(int d = getYPos() + 1 ; d <= j; d++ ){
            if(!isEmpty(i,d)){
                isempty = false;
                break;
            }                
        }
         }
                else if(getYPos() > j && getYPos() == i){
        for(int d = getXPos() -1 ; d >= j; d-- ){
            if(!isEmpty(i,d)){
                isempty = false;
                break;
            }                
        }
         }
         return isempty;
    }


    protected void marker(int i, int j, Object Rook) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void setXPos(int i) {
         this.i =i;
    }

    @Override
    protected void setYPos(int j) {
        this.j = j;
    }
    
}
