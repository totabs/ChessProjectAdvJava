//SOROUSH AGHAJANI
package chess;

/**
 *
 * @author aghaj
 */
abstract public class Move {
     static int counter =0 ;
   static Move[][] board = new Move[8][8];
   static boolean[][] empty = new boolean[8][8]; 
    int Xpos;
    int Ypos;
   static  boolean globTurn;
   // boolean empty;
    boolean oppExist;
    boolean pinned;
    protected boolean smallCastlable;
protected boolean bigCastlable;
        public boolean rNeverMoved;
       static public void truer(){
                    for(int row = 0; row < 8 ; row++){
    for(int col = 0; col <8 ;col++)
        empty[row][col] = true;
}
        }
       /* Rook smallRook = new Rook();
        King king = new King();
        bigRook bigRook = new bigRook();
        horse horse1 = new horse();
        horse horse2 = new horse();
        Bishop bishop1 = new Bishop();
        Bishop bishop2 = new Bishop();
        Queen queen = new Queen();*/
    abstract  protected void move(int i, int j, boolean move, Move moved);
    abstract protected boolean isMovable(int i, int j,Move movable);
    abstract protected int getXPos();
    abstract protected int getYPos();
     static  protected boolean isEmpty(int i,int j){

          return empty[i][j];
      }
      protected void newPos(int i, int j,Move move){
         // if(globTurn==true)
             // board[i][j] = move;
         // else if (globTurn == false)
          //    board[i][j]= move;
      }
          protected boolean isOpp(int i,int j){
              boolean opp = false;
             // if(globTurn = true && board[i][j]== -1 )
                  opp= true;
               //   else if(globTurn = true && board[i][j]==1 || board[i][j] == 0)
                 opp = false;
              
              
        return opp;
    }
          public void marker(int i, int j,  Move move){
             if(counter == 1){
              empty[0][0] = false;
             }
              int s;
              int b;
              s=move.getXPos();
              b = move.getYPos();
             // empty[move.getXPos()][move.getYPos()] = true;
      move.setYPos(j);
      move.setXPos(i);
              board[i][j]= move;
            empty[s][b] = true;
              empty[i][j] = false;
              counter ++;
              
        
    }
         abstract protected void setXPos(int i);
         abstract protected void setYPos(int j);
          protected void hit(int i ,int j){
        
    }
          protected boolean notPinned(){
        return true;
    }
    //abstract  public void newPos(int i, int j,Move move);
      protected void wrongMove(){
          System.out.println("wrong move");
      }
          public boolean smallRCastlable(boolean small){
        return small;
    }
        public boolean bigRCastlable(boolean big){
        return big;
    }
           static  public void smallCastle(King king, Rook smallRook,int i , int j){
         king.newPos(i, j, new King());
         smallRook.newPos(i-2,j,new Rook());
         
     }
                          public void bigCastle(King king, bigRook bigRook,int i , int j){
         king.newPos(i, j,new King());
         bigRook.newPos(i+2,j, new bigRook());
         
     }
}
